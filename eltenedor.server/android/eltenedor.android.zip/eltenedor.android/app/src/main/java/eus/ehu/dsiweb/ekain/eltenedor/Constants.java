package eus.ehu.dsiweb.ekain.eltenedor;


public class Constants {

    public static String SERVER_IP = "192.168.2.10";

    public static String SERVER_PORT = "8080";

    public static String SERVER_CONTEXT = "dsiweb.eltenedor.server";

    public static String SERVER_URL = "http://" + SERVER_IP + ":" + SERVER_PORT + "/" + SERVER_CONTEXT;

}
